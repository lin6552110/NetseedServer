package com.switek.netseed.server.bean;

public class AppVersion {
	String appName;
	String platform;
	String latestVersion;
	String releaseNotes;
	String Description;

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * @return the platform
	 */
	public String getPlatform() {
		return platform;
	}

	/**
	 * @param platform
	 *            the platform to set
	 */
	public void setPlatform(String platform) {
		this.platform = platform;
	}

	/**
	 * @return the latestVersion
	 */
	public String getLatestVersion() {
		return latestVersion;
	}

	/**
	 * @param latestVersion
	 *            the latestVersion to set
	 */
	public void setLatestVersion(String latestVersion) {
		this.latestVersion = latestVersion;
	}

	/**
	 * @return the releaseNotes
	 */
	public String getReleaseNotes() {
		return releaseNotes;
	}

	/**
	 * @param releaseNotes
	 *            the releaseNotes to set
	 */
	public void setReleaseNotes(String releaseNotes) {
		this.releaseNotes = releaseNotes;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return Description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		Description = description;
	}
}
