package com.switek.netseed.util;

import org.apache.commons.codec.binary.Base64;



public class MyBase64 {

	public MyBase64() {
		// TODO Auto-generated constructor stub
	}

	public static String encode(byte[] bstr) {
		return Base64.encodeBase64String(bstr);
	}
	
	
	public static byte[] decode(String s) {   
		 byte[] result = Base64.decodeBase64(s);
		 return result;
	}
	
}
