package com.switek.netseed.util;

public class Log {

}
