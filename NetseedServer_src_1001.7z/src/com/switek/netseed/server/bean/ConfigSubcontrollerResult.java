package com.switek.netseed.server.bean;

public class ConfigSubcontrollerResult  extends ActionResult{

	String subcontrollerId="";
	
	/**
	 * @return the subcontrollerId
	 */
	public String getSubcontrollerId() {
		return subcontrollerId;
	}
	/**
	 * @param deviceId the deviceId to set
	 */
	public void setSubcontrollerId(String subcontrollerId) {
		this.subcontrollerId = subcontrollerId;
	}
}
